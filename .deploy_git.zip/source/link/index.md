---
title: 示例
date: 2018-06-07 22:17:49
type: "link"
top_img: https://cdn.jsdelivr.net/gh/jerryc127/CDN@latest/Photo/friends.jpg
comments: false
---

***

如果你想把自己的網頁也新增到`示例`頁面，請


>1. 確保你使用 Butterfly 主題
>2. 點擊這個[鏈接](https://github.com/jerryc127/butterfly.js.org/edit/main/source/_data/link.yml)
>3. 按要求新增內容
>4. 點擊下面的 `Commit changes` ，合併到 butterfly.js.org 倉庫

